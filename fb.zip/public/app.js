 // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyC_txx3a7DLMGTzIhVU5D8zaDENI-O7Mp0",
    authDomain: "task-c19bd.firebaseapp.com",
    databaseURL: "https://task-c19bd.firebaseio.com",
    projectId: "task-c19bd",
    storageBucket: "task-c19bd.appspot.com",
    messagingSenderId: "971795060974",
    appId: "1:971795060974:web:fadf0e8636b4dc232a7bff"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

const db = firebase.firestore();


function test() 
{
if($('#pwd').val()!=""&&$('#email').val()!="")
 {	
 if($('#pwd').val()==$('#cpwd').val())
 {
        event.preventDefault();
        db.collection('employees').add({
             
                email: $('#email').val(),
                pwd: $('#pwd').val(),
                
            }).then(function () {
                console.log("Document successfully written!");
				window.location.href="login.html"
                
            })
            .catch(function (error) {
                console.error("Error writing document: ", error);
            });
   
 }
 else{
	 
	 alert('Confirm Password & Password not Matching');
 }
 }
else{
	 
	 alert('Please Fill the values');
 }
}

function testLogin()
{

}